--
-- PostgreSQL database dump
--

\restrict ppnKaUlL6YBBRB6JzkjVzzRmsOXmQ4oWzZ47LEFpvNhoLDJnFfwGlSt8hfcz3dM

-- Dumped from database version 16.12 (Debian 16.12-1.pgdg13+1)
-- Dumped by pg_dump version 16.12 (Debian 16.12-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    "accountId" text NOT NULL,
    "providerId" text NOT NULL,
    "userId" text NOT NULL,
    "accessToken" text,
    "refreshToken" text,
    "idToken" text,
    "accessTokenExpiresAt" timestamp(3) without time zone,
    "refreshTokenExpiresAt" timestamp(3) without time zone,
    scope text,
    password text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Account" OWNER TO postgres;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    token text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "ipAddress" text,
    "userAgent" text,
    "userId" text NOT NULL
);


ALTER TABLE public."Session" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    image text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: Verification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Verification" (
    id text NOT NULL,
    identifier text NOT NULL,
    value text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp(3) without time zone
);


ALTER TABLE public."Verification" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: ingredients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ingredients (
    id text NOT NULL,
    name text NOT NULL,
    price_per_unit double precision NOT NULL,
    description text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    category text NOT NULL,
    unit text NOT NULL
);


ALTER TABLE public.ingredients OWNER TO postgres;

--
-- Name: recipe_ingredients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recipe_ingredients (
    id text NOT NULL,
    recipe_id text NOT NULL,
    ingredient_id text NOT NULL,
    quantity double precision NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.recipe_ingredients OWNER TO postgres;

--
-- Name: recipes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recipes (
    id text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    image_url text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.recipes OWNER TO postgres;

--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Account" (id, "accountId", "providerId", "userId", "accessToken", "refreshToken", "idToken", "accessTokenExpiresAt", "refreshTokenExpiresAt", scope, password, "createdAt", "updatedAt") FROM stdin;
M61Szcf9uRm11F8y9TaLrQugpI8DTS93	gmC3mwS9sj4QdyzLA9DKCMor3KZGU54S	credential	gmC3mwS9sj4QdyzLA9DKCMor3KZGU54S	\N	\N	\N	\N	\N	\N	0da52a74643f777c5d0e707ec6ebd42d:d1560168b5d1a37e160382199dafc7b072332f93f44032154e7cd95a94b360b7deac2067974ee387b75a52c1ff51adc105567027dd14094cb1d31b7d03de7a7b	2026-03-04 19:36:40.845	2026-03-04 19:36:40.845
zQpNGZQUIxXrAussK6oTERwo1D2mGWES	5uAiRPPZ9kObg1zOOiesbF5ZTXVH64QF	credential	5uAiRPPZ9kObg1zOOiesbF5ZTXVH64QF	\N	\N	\N	\N	\N	\N	b21c85165f06d7d2eba9d15f0fb5e04a:2ba26f1c46fa7ff69a5adcfc7049194768ebf62d468083786e726dfbedc9968525913729f0effae9c4f4c2802925ee015210cb820109b96749e4b55d08851368	2026-03-04 19:37:22.553	2026-03-04 19:37:22.553
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Session" (id, "expiresAt", token, "createdAt", "updatedAt", "ipAddress", "userAgent", "userId") FROM stdin;
7vER9Cn7FiWpkYLph6bCTUotYdTJTQ5Q	2026-03-06 14:57:55.61	LcC1n3KSBkrsBnopx2ykTTATMIFJ5sj4	2026-03-05 14:57:55.61	2026-03-05 14:57:55.61	0000:0000:0000:0000:0000:0000:0000:0000	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	5uAiRPPZ9kObg1zOOiesbF5ZTXVH64QF
YeNuDJOEaNorbgYRJeZim0t2SPGP2mov	2026-03-06 19:31:36.184	xLmnSYVR3G29pTWL28V2QPzQxRsHFQOj	2026-03-05 19:31:36.185	2026-03-05 19:31:36.185	0000:0000:0000:0000:0000:0000:0000:0000	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	5uAiRPPZ9kObg1zOOiesbF5ZTXVH64QF
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, name, email, "emailVerified", image, "createdAt", "updatedAt") FROM stdin;
gmC3mwS9sj4QdyzLA9DKCMor3KZGU54S	Jasmine Mosley	kezugomeko@mailinator.com	f	\N	2026-03-04 19:36:40.837	2026-03-04 19:36:40.837
5uAiRPPZ9kObg1zOOiesbF5ZTXVH64QF	Serii	seriiburduja@gmail.com	f	\N	2026-03-04 19:37:22.55	2026-03-04 19:37:22.55
\.


--
-- Data for Name: Verification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Verification" (id, identifier, value, "expiresAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
2d3a68ff-55b5-4228-a33d-988a53ddeaa0	09d1804218aad63447d04e41becd371fdf796131a0608210b68520b6b604ce8c	2026-03-04 19:34:42.452605+00	20260303183938_better_auth_schema	\N	\N	2026-03-04 19:34:42.429622+00	1
73f2b12f-b4bd-43cf-80d3-b819d1416bcd	12ac38652e7bca3c9eb07647ea7ee6a21edbf1ea8785c148b34ad17d2673935a	2026-03-04 19:34:42.467222+00	20260304074015_users_table	\N	\N	2026-03-04 19:34:42.453636+00	1
ea36d739-9e27-4ee7-ab91-89d4d5afe9f4	1f055c6bda02b5105b138b38b8177b7abc6a4ea3e4b2a1166fb4f27a6c21725b	2026-03-04 19:34:42.475911+00	20260304192957_ingredients	\N	\N	2026-03-04 19:34:42.468186+00	1
8f5d2e90-ebbe-408a-b2ba-334e1505d317	5220335a7a0ac5328f11deccda169233ac57859de29fb09b917bc8c9edd49432	2026-03-04 19:34:43.318646+00	20260304193443_init	\N	\N	2026-03-04 19:34:43.287987+00	1
4e84e5c3-fa25-4c02-9f14-b8c8c2e318fd	86d1d02d61dede6553c6bf731b209fb6b7baab2059891143f0101241a8ec3343	2026-03-04 19:39:32.318206+00	20260304193932_options	\N	\N	2026-03-04 19:39:32.305726+00	1
3b637a37-6025-40b1-8d5f-ed1ba6c9899d	735e35e21a622b7f88d6053bdd11dbe7fc1dab6c2cc6f63b751f3cb6a12a1b93	2026-03-05 16:02:58.590801+00	20260305160258_category_units_to_string	\N	\N	2026-03-05 16:02:58.584327+00	1
75163f7d-8bc8-41d2-9611-d4fe6b642784	a483e4f0a43548f82b74032587724b80e2654c1bfe3c4606d5c79c63a9d3188a	2026-03-05 19:38:52.937725+00	20260305193852_recipe_engridients	\N	\N	2026-03-05 19:38:52.925032+00	1
\.


--
-- Data for Name: ingredients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ingredients (id, name, price_per_unit, description, "createdAt", "updatedAt", category, unit) FROM stdin;
cmmdsdhl60000wesbazi58jp8	Картошка	99	Corporis ad nihil en	2026-03-05 18:15:40.362	2026-03-05 19:17:12.088	fruits	grams
cmmdulauq0008wesb9rhec4uj	Хлеб	16	Tenetur veritatis do	2026-03-05 19:17:44.114	2026-03-05 19:17:55.023	spices	pieces
cmmdyratr000awesbegyza3ea	Moloko	14	Moloko of the cow	2026-03-05 21:14:22.478	2026-03-05 21:14:22.478	other	liters
\.


--
-- Data for Name: recipe_ingredients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recipe_ingredients (id, recipe_id, ingredient_id, quantity, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recipes (id, name, description, image_url, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Verification Verification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Verification"
    ADD CONSTRAINT "Verification_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: ingredients ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingredients
    ADD CONSTRAINT ingredients_pkey PRIMARY KEY (id);


--
-- Name: recipe_ingredients recipe_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_pkey PRIMARY KEY (id);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: Session_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Session_token_key" ON public."Session" USING btree (token);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Account Account_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: recipe_ingredients recipe_ingredients_ingredient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_ingredient_id_fkey FOREIGN KEY (ingredient_id) REFERENCES public.ingredients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: recipe_ingredients recipe_ingredients_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict ppnKaUlL6YBBRB6JzkjVzzRmsOXmQ4oWzZ47LEFpvNhoLDJnFfwGlSt8hfcz3dM

